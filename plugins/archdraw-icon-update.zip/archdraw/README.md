# ArchDraw plugin

This private Agent Plugin connects to ArchDraw's existing MCP server. It provides tools for architecture diagram generation, refinement, validation, layout, templates, checkpoints, and export.

The plugin launches the published `@hiabhee/archdraw-mcp-server` package with `npm exec` and points it at `https://archdraw.hiabhee.online`. Node.js 18+ and npm access are required on clients that run stdio MCP servers. To target another ArchDraw deployment, change `API_BASE_URL` in `mcp.json`.

The bundled skill describes when to use the tools and keeps publishing opt-in. The icon is copied from ArchDraw's existing product favicon.
